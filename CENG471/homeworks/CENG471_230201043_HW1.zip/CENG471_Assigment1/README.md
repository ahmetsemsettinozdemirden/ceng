# AES
Code is well documented with `javadoc`. You'll find all necessary explanations in the code.

# Implementation Environment
- `Intellij IDEA 2019.1.2`
- `JDK 1.8.0_202`
- `JVM OpenJDK 64-bit Server VM`

# Test
JUnit 5 is used as test tool. To understand code you can look at tests. Code coverage is %100 which means all cases are covered.

# App
I did not add any `main` or application entry method because this project is an library. If you want you can import project and use it for your own purposes.

# Screenshots
I added screenshots of tests and coverage.