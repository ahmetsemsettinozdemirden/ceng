package question3enhancedsolution;

public class CoinTossApp {

	public static void main(String[] args) {
		
		CoinGroup coinGroup = new CoinGroup(5);
		
		coinGroup.tossUntil("HEAD,HEAD,HEAD,HEAD,HEAD,");
	}


}
