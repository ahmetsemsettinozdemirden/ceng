package question3enhancedsolution;

public enum CoinFace {
	HEAD,
	TAIL
}
