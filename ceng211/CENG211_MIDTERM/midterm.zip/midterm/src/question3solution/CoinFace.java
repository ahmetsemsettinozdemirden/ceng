package question3solution;

public enum CoinFace {
	HEAD,
	TAIL
}
