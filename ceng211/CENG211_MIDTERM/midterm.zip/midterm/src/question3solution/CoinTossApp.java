package question3solution;

public class CoinTossApp {

	public static void main(String[] args) {
		
		FiveCoins fiveCoins = new FiveCoins();
		
		fiveCoins.tossUntilAllHeads();
	}


}
