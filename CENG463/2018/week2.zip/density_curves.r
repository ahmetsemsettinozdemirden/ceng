ipl<-iris$Petal.Length
hist(ipl,prob="true",ylim=c(0,1),main=NULL)
lines(density(ipl[iris$Species=="setosa"]),col="red")
lines(density(ipl[iris$Species=="versicolor"]),col="green")
lines(density(ipl[iris$Species=="virginica"]),col="blue")