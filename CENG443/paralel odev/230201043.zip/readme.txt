
- since i don't have any gpu on my machine, i couldn't try the saxpy code on my local env
- slurm-*.out files are from uhem.
- is.sh file is batch file for uhem.
- UHEM.png is a ss from uhem command line.
- saxpy.cu and wb.h are the source code.

Thank you
A. Semsettin Ozdemirden