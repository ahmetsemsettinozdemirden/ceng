images klasoru altinda uhem ile baslayan resimler blur islemi uygulanmis
resimler, test.cu dosyasinda is image blurring kernel'i implement edilmis 
kodlar bulunuyor. Zamanim kalmadigi icin performans acisindan istediklerinizi
yapamadim. Bunun icinsizden ozur diliyorum.

Iyi calismalar
Semsettin