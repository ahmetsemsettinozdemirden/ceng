// structure/presentation-model/CalcV3.java
//   Calculator with separation of presentation and model.
// Fred Swartz -- December 2004

// Program Organization: Separate View+Controller and Model

import javax.swing.*;

public class CalcV3 {
    public static void main(String[] args) {
        JFrame presentation = new CalcViewController();
        presentation.setVisible(true);
    }
}