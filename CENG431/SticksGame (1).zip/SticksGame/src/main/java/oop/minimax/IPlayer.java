// File: <<CLASSPATH>>/oop/minimax/IPlayer
package oop.minimax;

/**
 * Minimax needs to know that there are two Players, but doesn't care at all
 * about what constitutes a Player. Player references are used to give to the
 * Layout to determine the set of legal Moves for the Player,
 * and for evaluating a board from the Player's perspective.
 */
public interface IPlayer
{
}