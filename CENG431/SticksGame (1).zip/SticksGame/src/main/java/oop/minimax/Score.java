// File: <<CLASSPATH>>/oop/minimax/Score.java
package oop.minimax;

/**
 * Score is simply an "IntWrapper" class, allowing an empty score to be passed
 * into Minimax, which it fills with a value that the calling context can see.
 */
public class Score
{
  private int score;

  public Score()
  {
    score = Integer.MIN_VALUE;
  }

  public boolean equals( int score )
  {
    if( score == this.score )
    {
      return true;
    }
    return false;
  }

  public int getScore()
  {
    return score;
  }

  public void setScore( int s )
  {
    score = s;
  }

  public String toString()
  {
    return "" + score;
  }
}