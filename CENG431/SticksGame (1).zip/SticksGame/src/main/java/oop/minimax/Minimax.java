// File: <<CLASSPATH>>/oop/minimax/Minimax.java
package oop.minimax;

import java.util.*;

/**
 * Reusable algorithm for a computer player strategy for a two player game.
 * Search for the best move for the computer player. Apply the so-called
 * AlphaBeta variation of the Minimax algorithm, as a performance optimization.
 * Refer to http://www.SoftwareFederation.com/csci4448/download/minimax.pdf
 */
public final class Minimax
{
  /**
   * Valid scores range from -1 to 101.
   * Layout should use these public constants while scoring a board.
   * Layout should use 0..99 for a non-game-ending board evaluations.
   */
  public final static int SCORE_WIN      = 101;
  public final static int SCORE_LOSE     = -1;
  public final static int SCORE_TIE      = 100;

  /**
   * The values -+ Infinity are used to initialize the search
   */
  private final static int MINUS_INFINITY = Integer.MIN_VALUE;
  private final static int INFINITY       = Integer.MAX_VALUE;

  /**
   * When DEBUG is true, log messages get dumped to the Java console.
   */
  private static boolean DEBUG = false;

  /**
   * debugLogIndentations is used while printing DEBUG log messages.
   */
  private static String[] debugLogIndentations = null;

  /**
   * The layout is responsible for creating, processing & scoring moves.
   */
  private static ILayout layout = null;

  /**
   * The layout needs to know the current player so we must keep track...
   */
  private static IPlayer[] players = null;

  /**
   * No Minimax constructor; use Minimax.makeMove()...
   */
  private Minimax()
  {
  }

  /**
   * Used to calculate the indent Strings for DEBUG log messages.
   * The deeper the recursion, the larger the indent...
   * The debugLogIndentations array is created up front, for performance.
   */
  private static void configureDebugLogIndentations( int maxDepth )
  {
    if( DEBUG )
    {
      debugLogIndentations = new String[ maxDepth + 1 ];
      debugLogIndentations[ 0 ] = "";
      for( int i = 1; i <= maxDepth; i++ )
      {
        debugLogIndentations[ i ] = debugLogIndentations[ i - 1 ] + "  ";
      }
    }
  }

  /**
   * Optional ability to turn on DEBUG logging (default: off).
   */
  public static synchronized void enableDebugLog( boolean enable )
  {
    Minimax.DEBUG = enable;
  }

  /**
   * If the protagonist has a sure win, that could be because no matter what
   * the player does this turn, there will still be a guaranteed win on the
   * next turn (as is the case sometimes if there is more than one winning move).
   * In such a case, without this method, the player would take the first move
   * in the legalMoves list, whether that move ends the game this turn or not.
   * Let's get the game over with already. Ensure that a game ending move is
   * taken, if one exists.
   */
  private static IMove endGameNowIfPossible( Vector legalMoves, ILayout layout )
  {
    IMove move = null;
    Enumeration moves = legalMoves.elements();
    while( moves.hasMoreElements() )
    {
      move = (IMove) moves.nextElement();
      layout.processMove( move ); // MUST undo this
      if( layout.isGameOver() )
      {
        layout.unprocessMove( move );
        return move; // Winner!
      }
      layout.unprocessMove( move );
    }
    return move;
  }

  /**
   * Get a score from the layout.  Ensure that it is in the valid range.
   * For increased performance, the Layout should assume that the game
   * is not over; this assumption is enforced elsewhere in the code.
   */
  private static int evaluateBoard( IPlayer player )
  {
    int score = layout.evaluateBoard( player );
    if( score >= SCORE_TIE )
    {
      System.out.println( "Minimax WARNING - score too big !!!!!" + score );
      score = SCORE_TIE - 1;
    }
    if( score <= SCORE_LOSE )
    {
      System.out.println( "Minimax WARNING - score too small !!!!!" + score );
      score = SCORE_LOSE + 1;
    }
    return score;
  }

  /**
   * Each level of recursive search alternates between players...
   */
  private static IPlayer getOtherPlayer( IPlayer player )
  {
    if( players[ 0 ] == player )
    {
      return players[ 1 ];
    }
    else
    {
      return players[ 0 ];
    }
  }

  /**
   * Log indented messages, if in DEBUG mode.
   * The indentations show the depth of the recursion.
   */
  private static final void log( String msg, int recursionDepth )
  {
    if( DEBUG )
    {
      int indentIndex = debugLogIndentations.length - recursionDepth - 1;
      System.out.println( debugLogIndentations[ indentIndex ] + msg );
    }
  }

  /**
   * Minimax's primary method, the entry point for the computer player !!!
   * This must the top level of the search, thus behave like a MAXimizing node.
   * Clients who care about the final score may pass in a non-null Score.
   */
  public static synchronized IMove makeMove( IPlayer[] players,
                                             ILayout layout,
                                             int maxDepth,
                                             IPlayer protagonist,
                                             Score finalScore )
  {
    Minimax.players = players;
    Minimax.layout = layout;
    if( players == null || layout == null )
    {
      System.out.println( "Minimax ERROR ! null value !!!!!" );
      return null;
    }
    if( maxDepth < 1 )
    {
      System.out.println( "Minimax ERROR ! Use max search depth >= 1 !!!!!" );
      return null;
    }

    // Initialize "the best so far" for new search
    int   bestScoreSoFar = MINUS_INFINITY;
    IMove bestMoveSoFar = null;
    boolean allMovesWin = true;

    try
    {
      configureDebugLogIndentations( maxDepth );

      // Initialize ALPHA & BETA for new search
      int alpha = MINUS_INFINITY;
      int beta = INFINITY;

      // Ask the layout for all the possible legal moves.
      // Try them all...
      Vector legalMoves = layout.getAllLegalMoves( protagonist );
      Enumeration moves = legalMoves.elements();
      while( moves.hasMoreElements() )
      {
        IMove nextMove = (IMove) moves.nextElement();

        layout.processMove( nextMove ); // MUST undo this later
        try
        {
          log( "TOP MAX node... Try Move : " + nextMove, maxDepth );

          int score = minimaxMIN( maxDepth - 1, alpha, beta, protagonist );

          log( "TOP MAX node... Move scored : " + score, maxDepth );

          if( score > bestScoreSoFar )
          {
            // Remember the Move that gave us this best score
            bestScoreSoFar = score;
            bestMoveSoFar = nextMove;
          }
          if( score != SCORE_WIN )
          {
            allMovesWin = false;
          }
        }
        catch( Throwable t )
        {
          System.out.println( "Minimax ERRROR !!! " );
          t.printStackTrace();
        }
        layout.unprocessMove( nextMove ); // undone for sure.
      }
      if( bestMoveSoFar == null )
      {
        System.out.println( "Minimax WARNING - no move found !!!!!" );
        return null;
      }

      log( "TOP MAX node... DONE!!! Best Score = " + bestScoreSoFar, maxDepth );
      if( finalScore != null )
      {
        finalScore.setScore( bestScoreSoFar );
      }
      if( allMovesWin )
      {
        log( "TOP MAX node... All Moves win!", maxDepth );
        bestMoveSoFar = endGameNowIfPossible( legalMoves, layout );
      }
    }
    catch( Throwable t )
    {
      System.out.println( "Minimax ERRROR !!! " );
      t.printStackTrace();
    }
    return bestMoveSoFar;
  }

  /**
   * Return the maximum guaranteed score for this "node" in the search tree.
   */
  private static int minimaxMAX( int depth, int alpha, int beta, IPlayer player )
  {
    if( layout.isGameOver() )
    {
      if( layout.isTied() )
      {
        log( "MAX node... TIED ... " + SCORE_TIE, depth );
        return SCORE_TIE;
      }
      log( "MAX node... LOSE ... " + SCORE_LOSE, depth );
      return SCORE_LOSE;
    }
    if( depth == 0 )
    {
      // No more search allowed.  Ask the layout...
      int score = evaluateBoard( player );
      log( "MAX node... EVAL = " + score, depth );
      return score;
    }

    IPlayer otherPlayer = getOtherPlayer( player );
    Vector moves = layout.getAllLegalMoves( otherPlayer );
    Enumeration legalMoves = moves.elements();

    while( legalMoves.hasMoreElements() )
    {
      IMove nextMove = (IMove) legalMoves.nextElement();
      layout.processMove( nextMove ); // MUST undo this later
      try
      {
        log( "MAX node... Try Move : " + nextMove, depth );

        int score = minimaxMIN( depth - 1, alpha, beta, otherPlayer );

        alpha = Math.max( alpha, score );

        log( "MAX node... Move scored : " + score +
             " ( A = " + alpha + " : B = " + beta + " )", depth );

        if( alpha >= beta )
        {
          // Prune!
          log( "MAX Node... PRUNING... " +
               "( A = " + alpha + " : B = " + beta + " )", depth );
          layout.unprocessMove( nextMove );
          return alpha;
        }
      }
      catch( Throwable t )
      {
        System.out.println( "Minimax ERRROR !!! " );
        t.printStackTrace();
      }

      layout.unprocessMove( nextMove );  // undone for sure.
    }
    log( "MAX node... Final score = " + alpha, depth );

    return alpha;
  }

  /**
   * Return the minimum guaranteed score for this "node" in the search tree.
   */
  private static int minimaxMIN( int depth, int alpha, int beta, IPlayer player )
  {
    if( layout.isGameOver() )
    {
      if( layout.isTied() )
      {
        log( "MIN node... TIED ... " + SCORE_TIE, depth );
        return SCORE_TIE;
      }
      log( "MIN node... WIN ... " + SCORE_WIN, depth );
      return SCORE_WIN;
    }
    if( depth == 0 )
    {
      // No more search allowed.  Ask the layout...
      int score = evaluateBoard( player );
      log( "MIN node... EVAL = " + score, depth );
      return score;
    }

    IPlayer otherPlayer = getOtherPlayer( player );
    Vector moves = layout.getAllLegalMoves( otherPlayer );
    Enumeration legalMoves = moves.elements();

    while( legalMoves.hasMoreElements() )
    {
      IMove nextMove = (IMove) legalMoves.nextElement();
      layout.processMove( nextMove ); // MUST undo this later
      try
      {
        log( "MIN node... Try Move : " + nextMove, depth );

        int score = minimaxMAX( depth - 1, alpha, beta, otherPlayer );

        beta = Math.min( beta, score );

        log( "MIN node... Move scored : " + score +
             "( A = " + alpha + " : B = " + beta + " )", depth );

        if( alpha >= beta )
        {
          // Prune!
          log( "MIN Node... PRUNING... " +
               " ( A = " + alpha + " : B = " + beta + " )", depth );
          layout.unprocessMove( nextMove );
          return beta;
        }
      }
      catch( Throwable t )
      {
        System.out.println( "Minimax ERRROR !!! " );
        t.printStackTrace();
      }

      layout.unprocessMove( nextMove );  // undone for sure.
    }
    log( "MIN node... Final score = " + beta, depth );
    return beta;
  }
}

//  !!!! Welcome to the Sticks Game !!!!
//  Human #1... What is your name?  Dave
//  << Dave >> VS. << CP #1 MiniMax depth=3 >> !!!!
//  1. |
//  2. ||
//  3. |||
//
//  << Dave >> It is your turn ...
//  Which row ???  3
//  How many sticks ???  3
//  << Dave >> moved: ( Row = 3 : Num Sticks = 3 )
//
//  1. |
//  2. ||
//  3.
//
//  << CP #1 MiniMax depth=3 >> It is your turn ...
//  TOP MAX node... Try Move : ( Row = 1 : Num Sticks = 1 )
//    MIN node... Try Move : ( Row = 2 : Num Sticks = 1 )
//      MAX node... LOSE ... -1
//    MIN node... Move scored : -1( A = -2147483648 : B = -1 )
//    MIN node... Final score = -1
//  TOP MAX node... Move scored : -1
//  TOP MAX node... Try Move : ( Row = 2 : Num Sticks = 1 )
//    MIN node... Try Move : ( Row = 1 : Num Sticks = 1 )
//      MAX node... LOSE ... -1
//    MIN node... Move scored : -1( A = -2147483648 : B = -1 )
//    MIN node... Try Move : ( Row = 2 : Num Sticks = 1 )
//      MAX node... LOSE ... -1
//    MIN node... Move scored : -1( A = -2147483648 : B = -1 )
//    MIN node... Final score = -1
//  TOP MAX node... Move scored : -1
//  TOP MAX node... Try Move : ( Row = 2 : Num Sticks = 2 )
//    MIN node... WIN ... 101
//  TOP MAX node... Move scored : 101
//  TOP MAX node... DONE!!! Best Score = 101
//  MINIMAX score for next move = 101
//  I've got you now... ha ha ha !!!
//  << CP #1 MiniMax depth=3 >> moved: ( Row = 2 : Num Sticks = 2 )
//
//  1. |
//  2.
//  3.
//
//  << CP #1 MiniMax depth=3 >> is the WINNER !!!!
