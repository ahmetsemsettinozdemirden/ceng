// File: <<CLASSPATH>>/oop/minimax/ILayout
package oop.minimax;

import java.util.Vector;

/**
 * Minimax requires some knowledge about the game's Layout...
 */
public interface ILayout
{
  /**
   * Return a score for the board between Minimax.SCORE_LOSE + 1 and
   * Minimax.SCORE_TIE - 1, inclusive ( 0..99 )
   * For increased performance, the Layout should assume that the game
   * is not over; this assumption is enforced elsewhere in the Minimax code.
   * A given board might be good or bad, depending on which player is looking.
   * Note: Minimax still works if this method returns a random score,
   * for simple games, but for large & complex games such as chess,
   * it is necessary to design a "static board evaluation heuristic".
   */
  public int evaluateBoard( IPlayer player );

  /**
   * Return a Vector that contains all legal IMoves for the given player.
   */
  public Vector getAllLegalMoves( IPlayer player );

  /**
   * Return true for a win, lose, or tie, else false.
   */
  public boolean isGameOver();

  /**
   * Return true if game has ended in a tie, else false.
   */
  public boolean isTied();

  /**
   * Change the state of the Layout by applying a Move.
   * See unprocessMove().
   */
  public void processMove( IMove move );

  /**
   * Minimax guarantees that for every call to processMove() that it makes,
   * there will be a corresponding call to unprocessMove() to undo the move.
   */
  public void unprocessMove( IMove move );
}