// File: <<CLASSPATH>>/oop/minimax/IMove
package oop.minimax;

/**
 * Minimax needs to know about the concept of a Move,
 * but doesn't care at all about what constitutes a Move.
 */
public interface IMove
{
}