// File: <<CLASSPATH>>/oop/xml/XMLizable.java
package oop.xml;

import org.jdom.Element;

/**
 * Interface for objects that are configurable with XML.
 * Refer to XMLFactory.  Concrete implementors of this interface
 * MUST output a "className" Attribute in their toXML() methods.
 */
public interface XMLizable
{
  public static final String CLASS_NAME = "className";

  public Element toXML();
  public void    initFromXML( Element ele ) throws Exception;
}