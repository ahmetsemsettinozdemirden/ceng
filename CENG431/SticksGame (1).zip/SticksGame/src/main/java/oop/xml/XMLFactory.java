// File: <<CLASSPATH>>/oop/xml/XMLFactory.java
package oop.xml;

import java.io.*;
import org.jdom.*;
import org.jdom.input.SAXBuilder;
import org.jdom.output.XMLOutputter;

/**
 * Facilitate using XML to configure domain objects.
 * Assumes that all such objects are XMLizable and that all Elements produced
 * have an Attribute called "className".
 *
 * You MUST have both xerces.jar and jdom.jar in your classpath to use.
 */
public class XMLFactory
{
  /**
   * Use the public static methods: makeObject(), readFile(), writeFile()
   */
  private XMLFactory()
  {
  }

  /**
   * Create an XMLizable object from the JDOM Element.
   */
  public static XMLizable makeObject( Element config )
  throws Exception
  {
    XMLizable domainObject = null;
    Attribute classAttribute = config.getAttribute( XMLizable.CLASS_NAME );
    String className = classAttribute.getValue();
    domainObject = (XMLizable) Class.forName( className ).newInstance();
    domainObject.initFromXML( config );
    return domainObject;
  }

  /**
   * Read an XML file and return the Document's XMLizable root Element.
   */
  public static XMLizable readFile( String fileName )
  {
    XMLizable rootObject = null;
    try
    {
      SAXBuilder builder = new SAXBuilder();
      Document doc = builder.build( new FileInputStream( fileName ) );
      Element rootElement = doc.getRootElement();
      rootObject = makeObject( rootElement );
    }
    catch( Throwable t )
    {
      System.out.println( "XMLFactory ERROR cannot read XML file " + fileName );
      t.printStackTrace();
      return null;
    }
    return rootObject;
  }

  /**
   * Write an XML file, given the Document's root XMLizable Element.
   */
  public static void writeFile( String fileName, XMLizable rootObject )
  {
    try
    {
      Element rootElement = rootObject.toXML();
      Document doc = new Document( rootElement );
      XMLOutputter out = new XMLOutputter();
//      out.setIndent( true );
//      out.setNewlines( true );
      out.output( doc, new FileOutputStream( fileName ) );
    }
    catch( Throwable t )
    {
      System.out.println( "XMLFactory ERROR cannot write XML file " + fileName );
      t.printStackTrace();
    }
  }
}