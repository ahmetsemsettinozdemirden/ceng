package oop.utils;

import java.io.*;

public class StackTrace
{
  public static String toString( Throwable t )
  {
    ByteArrayOutputStream baos = new ByteArrayOutputStream();
    PrintWriter pw = new PrintWriter( baos );
    t.printStackTrace( pw );
    pw.flush();
    String trace = baos.toString();
    pw.close();
    return trace;
  }
}