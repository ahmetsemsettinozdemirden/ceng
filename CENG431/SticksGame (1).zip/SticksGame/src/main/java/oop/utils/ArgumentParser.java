// File: <<CLASSPATH>>/oop/utils/ArgumentParser.java
package oop.utils;

/**
 * Useful for organizing command-line arguments for a Java application.
 * Pass in main's String[] of args...  Assumes a command-line of the form:
 * java pkg.appName optionOne=7 optionTwo=11 foo
 * getOption( "optionOne" ) would return "7"
 * hasOption( "foo" ) would return true
 * Note: all argument keys are converted to lower case.
 */
public class ArgumentParser extends java.util.Hashtable
{
  public ArgumentParser( String[] args )
  {
    super();
    for( int i = 0; i < args.length; i++ )
    {
      int loc = args[i].indexOf("=");
      String key = ( loc > 0 ) ? args[i].substring( 0, loc ) : args[i];
      String value = ( loc > 0 ) ? args[i].substring( loc + 1 ) : "";
      put( key.toLowerCase(), value );
    }
  }

  public String getOption( String opt )
  {
    return (String) get( opt.toLowerCase() );
  }

  public boolean hasOption( String opt )
  {
    return containsKey( opt.toLowerCase() );
  }
}