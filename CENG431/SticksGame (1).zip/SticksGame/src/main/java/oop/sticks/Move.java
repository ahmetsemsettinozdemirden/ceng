// File: <<CLASSPATH>>/oop/sticks/Move.java
package oop.sticks;

import java.io.Serializable;
import oop.minimax.IMove;
import oop.xml.XMLizable;
import org.jdom.*;

/**
 * Sticks game move.
 */
public class Move implements IMove, XMLizable, Serializable
{
  private int   row;
  private int   numSticks;

  /**
   * Default constructor for XML Factory
   */
  public Move()
  {
    init( -1, -1 );
  }

  public Move( int row, int numSticks )
  {
    init( row, numSticks );
  }

  public int getRow()
  {
    return row;
  }

  public int getNumSticks()
  {
    return numSticks;
  }

  private void init( int row, int numSticks )
  {
    this.row = row;
    this.numSticks = numSticks;
  }

  public void initFromXML( Element config )
  throws Exception
  {
    Attribute rowAttribute = config.getAttribute( "row" );
    String rowString = rowAttribute.getValue();
    int row = Integer.valueOf( rowString.trim() ).intValue();

    Attribute numSticksAttribute = config.getAttribute( "numSticks" );
    String numSticksString = numSticksAttribute.getValue();
    int numSticks = Integer.valueOf( numSticksString.trim() ).intValue();

    init( row, numSticks );
  }

  public Element toXML()
  {
    Element move = new Element( "move" );

    Attribute classAttr = new Attribute( CLASS_NAME, "" + getClass().getName() );
    move.setAttribute( classAttr );

    Attribute rowAttribute = new Attribute( "row", "" + getRow() );
    move.setAttribute( rowAttribute );

    Attribute numSticksAttribute = new Attribute( "numSticks", "" + getNumSticks() );
    move.setAttribute( numSticksAttribute );

    return move;
  }

  public String toString()
  {
    return "( Row = " + getRow() + " : Num Sticks = " + getNumSticks() + " ) ";
  }
}
