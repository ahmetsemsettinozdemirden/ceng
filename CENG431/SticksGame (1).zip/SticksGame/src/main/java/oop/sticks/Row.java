// File: <<CLASSPATH>>/oop/sticks/Row.java
package oop.sticks;

import java.io.Serializable;
import java.util.*;

/**
 * Part of the layout
 */
public class Row implements Serializable
{
  private int    maxSticks = -1;
  private Vector sticks    = new Vector();

  public Row( int maxSticks )
  {
    this.maxSticks = maxSticks;
    addSticks( maxSticks );
  }

  public int getNumSticks()
  {
    return sticks.size();
  }

  /**
   * return true if the row has at least 'num' sticks
   */
  public boolean isValidMove( int num )
  {
    return ( 1 <= num && num <= getNumSticks() );
  }

  public void removeSticks( int numSticks )
  {
    // Assumes that this is a legal move (checked elsewhere)
    for( int i = numSticks - 1; i >= 0; i-- )
    {
      sticks.remove( i );
    }
  }

  public void addSticks( int numSticks )
  {
    for( int i = 0; i < numSticks; i++ )
    {
      sticks.addElement( new Stick() );
    }
  }

  /**
   * Display the row to the Java Console.
   */
  public void display()
  {
    Enumeration enumaration = sticks.elements();
    while( enumaration.hasMoreElements() )
    {
      Stick s = (Stick) enumaration.nextElement();
      s.display();
    }
  }
}