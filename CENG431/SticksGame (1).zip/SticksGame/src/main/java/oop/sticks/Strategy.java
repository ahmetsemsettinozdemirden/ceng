package oop.sticks;

import java.io.Serializable;

/**
 * Computer player strategy.
 */
public interface Strategy extends Serializable
{
  public Move makeMove();
}