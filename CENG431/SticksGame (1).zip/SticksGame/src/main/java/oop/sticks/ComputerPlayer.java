// File: <<CLASSPATH>>/oop/sticks/ComputerPlayer.java
package oop.sticks;

import oop.xml.XMLizable;
import org.jdom.*;

/**
 * Game player that uses a Minimax or Random "AI" strategy.
 */
public class ComputerPlayer extends Player
{
  private        int         maxSearchDepth       = 5; // default
  private static int         numComputers         = 0;
  private        Strategy    strategy             = null;

  /**
   * Determine (and set) this player's name
   */
  public void determineName()
  {
    if( maxSearchDepth == 0 )
    {
      setName( "<< CP #" + ( ++numComputers ) + " Random >>" );
    }
    else
    {
      setName( "<< CP #" + ( ++numComputers ) +
               " MiniMax depth=" + maxSearchDepth + " >>" );
    }
  }

  public int getMaxSearchDepth()
  {
    return maxSearchDepth;
  }

  public void initFromXML( Element config )
  throws Exception
  {
    super.initFromXML( config );

    Attribute depthAttribute = config.getAttribute( "depth" );
    String depthString = depthAttribute.getValue();
    maxSearchDepth = Integer.valueOf( depthString.trim() ).intValue();
  }

  /**
   * Initialize the "AI" strategy.
   */
  public void initStrategy( int depth, Player[] players, Layout layout )
  {
    maxSearchDepth = depth;
    if( depth <= 0 )
    {
      strategy = new RandomStrategy( this, layout );
    }
    else
    {
      strategy = new MinimaxStrategy( this, layout, depth, players );
    }
    determineName();
  }

  public Move makeMove()
  {
    return strategy.makeMove();
  }

  public Element toXML()
  {
    Element player = super.toXML();

    Attribute depthAttribute = new Attribute( "depth", "" + maxSearchDepth );
    player.setAttribute( depthAttribute );

    return player;
  }
}
