// File: <<CLASSPATH>>/oop/sticks/RandomStrategy.java
package oop.sticks;

/**
 * Game strategy that makes random moves.
 */
public class RandomStrategy implements Strategy
{
  private Player player;
  private Layout layout;

  /**
   * Create a random strategy.  Since this class relies on the fact that
   * the Layout has a getAllLegalMoves() method, pass in the layout
   * and a player reference that that method requires.
   */
  public RandomStrategy( Player player, Layout layout )
  {
    this.player = player;
    this.layout = layout;
  }

  /**
   * Make a random, legal move.
   */
  public Move makeMove()
  {
    java.util.Vector legalMoves = layout.getAllLegalMoves( player );
    Move move = null;
    java.util.Random randy = new java.util.Random( System.currentTimeMillis() );
    int moveIndex = Math.abs( randy.nextInt() ) % legalMoves.size();
    move = (Move)legalMoves.elementAt( moveIndex );
    return move;
  }
}