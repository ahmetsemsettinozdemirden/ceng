// File: <<CLASSPATH>>/oop/sticks/Referee.java
package oop.sticks;

import java.io.Serializable;
import oop.utils.*;
import oop.minimax.*;

/**
 * Sticks game controller / mediator.
 */
public class Referee implements Serializable
{
  private Player    curPlayer = null;
  private Layout    layout    = null;
  private Player[]  players   = null;

  /**
   * The game is over, who won?
   */
  public void announceWinner()
  {
    System.out.println();
    IPlayer victor = determineWinner();
    if( victor != null )
    {
      System.out.println( victor + " is the WINNER !!!!" );
    }
  }

  /**
   * Play a game.
   * Throws SaveGameException if the HumanPlayer decides to save the game.
   */
  public void conductGame() throws SaveGameException
  {
    layout.display();
    Move move = null;

    while( ! layout.isGameOver( ) )
    {
      boolean isValidMove = false;
      do
      {
        System.out.println();
        System.out.println( curPlayer + " It is your turn ..." );

        move = curPlayer.makeMove();

        isValidMove = layout.isValidMove( move );
        if( ! isValidMove )
        {
          System.out.println( curPlayer + " That is NOT a VALID Move !!! " );
          layout.display();
        }
      }
      while( ! isValidMove );

      System.out.println( curPlayer + " moved: " + move );
      System.out.println();
      layout.processMove( move );
      layout.display();
      curPlayer = getNextPlayer();
    }
  }

  /**
   * Who won?
   */
  private Player determineWinner()
  {
    if( layout.getNumSticks() == 0 )
    {
      return curPlayer;
    }
    return getNextPlayer();
  }

  /**
   * Alternate players.
   */
  private Player getNextPlayer()
  {
    if( players[ 0 ] == curPlayer )
    {
      return players[ 1 ];
    }
    else
    {
      return players[ 0 ];
    }
  }

  /**
   * Initialize the ref.
   */
  public void init( Player[] players, Layout layout )
  {
    this.players = players;
    this.layout = layout;
    curPlayer = players[ 0 ];
  }

  public void setNextPlayer( Player player )
  {
    curPlayer = player;
  }
}
