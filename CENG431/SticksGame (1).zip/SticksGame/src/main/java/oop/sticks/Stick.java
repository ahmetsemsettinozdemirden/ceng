// File: <<CLASSPATH>>/oop/sticks/Piece.java
package oop.sticks;

import java.io.Serializable;

/**
 * Part of te Sticks game layout.
 */
public class Stick implements Serializable
{
  /**
   * Display the layout to the Java Console.
   */
  public void display()
  {
    System.out.print( "|" );
  }
}