// File: <<CLASSPATH>>/cs4448/sticks/HumanPlayer.java
package oop.sticks;

import oop.utils.Console;
import oop.minimax.*;

/**
 * Console-based game player that asks a human actor for a move.
 */
public class HumanPlayer extends Player
{
  private static int numHumans = 0;

  /**
   * Determine (and set) this player's name
   */
  public void determineName()
  {
    String tmpName = "Human #" + ( ++numHumans );

    try
    {
      System.out.println();
      String prompt = tmpName + "... What is your name? ";
      String inputLine = Console.readLine( prompt ).trim();
      if( inputLine.length() != 0 )
      {
        tmpName = inputLine.trim();
      }
    }
    catch( Throwable t )
    {
      System.out.println( "Sticks WARNING ! could not get human player name." );
    }
    setName( "<< " + tmpName + " >>" );
  }

  /**
   * Make a move in the game.
   * Throws SaveGameException if the user types "save xxx"
   */
  public Move makeMove()
  throws SaveGameException
  {
    System.out.println();
    String prompt = "Which row ??? ";
    String reply = Console.readLine( prompt ).trim();

    int lengthOfSaveString = 5;
    if( reply.indexOf( "save " ) == 0 &&
        reply.length() > lengthOfSaveString &&
        reply.substring( lengthOfSaveString ).length() > 0 )
    {
      // NOTE: this design is intended to exemplify Java's Exception Handling.
      // Generally, it is not considered good style to throw exceptions,
      // except for truly exceptional situations.
      // On the other hand, this code is pretty clean.
      // Caught by main().
      String saveName = reply.substring( lengthOfSaveString ).trim();
      throw new SaveGameException( saveName );
    }

    try
    {
      int row = Integer.parseInt( reply );
      prompt = "How many sticks ??? ";
      reply = Console.readLine( prompt ).trim();
      int numSticks = Integer.parseInt( reply );
      Move move = new Move( row, numSticks );
      return move;
    }
    catch( Throwable ignore ) { } // return null is OK
    return null;
  }
}

