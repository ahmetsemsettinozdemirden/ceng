// File: <<CLASSPATH>>/oop/sticks/Layout.java
package oop.sticks;

import java.util.*;
import java.io.Serializable;
import oop.minimax.*;

/**
 * Sticks game layout.  Designed to work with a Minimax search algorithm.
 */
public class Layout implements ILayout, Serializable
{
  private        Vector   moves = new Vector();
  private        int      numRows = 5;
  private static Random   random = new Random( System.currentTimeMillis() );
  private        Row[]    rows;

  /**
   * Create a layout.
   * Note the init() is OK since it does not call any polymorphic methods.
   */
  public Layout()
  {
    init();
  }

  /**
   * Display the layout to the Java Console.
   */
  public void display()
  {
    for( int i = 1; i <= numRows; i++ )
    {
      System.out.print( i );
      System.out.print( ". " );
      rows[ i-1 ].display(); // note 0-based and 1-based translation
      System.out.println();
    }
  }

  /**
   * Until we get around to writing a good Sticks heuristic board evaluator,
   * use a random number...  This is good enough.  Note, we do not need
   * to check for a win or lose, since minimax checks for this elsewhere.
   * This method returns a random number from 0..99, as required.
   */
  public int evaluateBoard( IPlayer protagonist )
  {
    return ( Math.abs( random.nextInt() ) ) % Minimax.SCORE_TIE;
  }

  /**
   * Find all the possible legal moves....
   * It is not considered to be legal to remove the last stick.
   * Of course, a human player doesn't call this code, and can suicide.   *
   */
  public Vector getAllLegalMoves( IPlayer player )
  {
    int sticksRemaining = getNumSticks();
    Vector moves = new Vector();
    for( int i = 1; i <= numRows; i++ )
    {
      int numSticks = rows[ i - 1 ].getNumSticks();
      for( int j = 1; j <= numSticks; j++ )
      {
        if( sticksRemaining != j )
        {
          // Don't remove the last stick
          Move m = new Move( i, j );
          moves.addElement( m );
        }
      }
    }
    return moves;
  }

  public Vector getMoves()
  {
    return moves;
  }

  /**
   * Get total number of sticks left.
   */
  public int getNumSticks()
  {
    int cnt = 0;
    for( int i = 0; i < numRows; i++ )
    {
      cnt += rows[ i ].getNumSticks();
    }
    return cnt;
  }

  /**
   * (re)create the rows.
   */
  public void init()
  {
    rows = new Row[ numRows ];
    for( int i = 1; i <= numRows; i++ )
    {
      rows[ i - 1 ] = new Row( i );
    }
  }

  /**
   * A game is over with 0 or 1 stick left (need both cases).
   */
  public boolean isGameOver()
  {
    return getNumSticks() <= 1;
  }

  /**
   * No tie in Sticks, but Minimax has to ask.
   */
  public boolean isTied()
  {
    return false;
  }

  /**
   * Returns true if the move is legal.
   */
  public boolean isValidMove( Move move )
  {
    if( move == null )
    {
      return false;
    }

    if( 1 <= move.getRow() && numRows >= move.getRow() )
    {
      return rows[ move.getRow()-1 ].isValidMove( move.getNumSticks() );
    }
    else
    {
      return false;
    }
  }

  /**
   * Do the move; update the board.
   */
  public void processMove( IMove m )
  {
    Move move = (Move)m;
    int numSticks = move.getNumSticks();
    int row = move.getRow() -1;
    rows[ row ].removeSticks( numSticks );
    moves.addElement( move );
  }

  /**
   * Configure the board to have N rows.
   */
  protected void setNumRows( int numRows )
  {
    this.numRows = numRows;
    init();
  }

  /**
   * Undo a move (used by minimax, but could be used also to support
   * an undo feature for the game)..
   */
  public void unprocessMove( IMove m )
  {
    Move move = (Move)m;
    int numSticks = move.getNumSticks();
    int row = move.getRow() -1;
    rows[ row ].addSticks( numSticks );
    moves.removeElement( moves.lastElement() );
  }
}
