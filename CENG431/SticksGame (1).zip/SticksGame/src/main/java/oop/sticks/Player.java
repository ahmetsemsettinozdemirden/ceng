// File: <<CLASSPATH>>/cs4448/sticks/Player.java
package oop.sticks;

import oop.minimax.IPlayer;
import oop.xml.XMLizable;
import org.jdom.*;
import java.io.Serializable;

/**
 * Game player.
 */
public abstract class Player implements IPlayer, XMLizable, Serializable
{
  private String name;

  /**
   * Determine (and set) this player's name
   */
  protected abstract void determineName();

  public void initFromXML( Element config )
  throws Exception
  {
    Attribute nameAttribute = config.getAttribute( "name" );
    name = nameAttribute.getValue();
  }

  public final String getName()
  {
    return name;
  }

  /**
   * Make a move in the game.
   * Throws SaveGameException if the HumanPlayer decides to save the game.
   */
  public abstract Move makeMove() throws SaveGameException;

  protected void setName( String name )
  {
    this.name = name;
  }

  public final String toString()
  {
    return name;
  }

  public Element toXML()
  {
    Element player = new Element( "player" );

    Attribute classAttr = new Attribute( CLASS_NAME, "" + getClass().getName() );
    player.setAttribute( classAttr );

    Attribute nameAttribute = new Attribute( "name", getName() );
    player.setAttribute( nameAttribute );

    return player;
  }
}
