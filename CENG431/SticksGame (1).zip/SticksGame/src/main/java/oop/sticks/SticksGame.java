// File: <<CLASSPATH>>/oop/sticks/SticksGame.java
package oop.sticks;

import oop.utils.*;
import oop.utils.Console;
import oop.minimax.*;
import oop.xml.*;
import org.jdom.*;
import org.jdom.input.SAXBuilder;
import org.jdom.output.XMLOutputter;
import java.util.*;
import java.io.*;

/**
 *  SticksGame !!!!  This class is responsible for playing a game...
 *  This class controls the construction process of the Layout, the Referee,
 *  and the Players; it then asks the Referee to conduct a game.
 *  SticksGame also deals with saving and restoring games
 *  (using either XML or Java SERialization technology).
 *  Because SticksGame uses XML, you must include jdom.jar
 *  in your classpath to compile and run this code.
 *  Example Command lines:
 *  java oop.sticks.SticksGame P0=H P1=C rows=6 file=game3 SER DEBUG
 *  java oop.sticks.SticksGame P0=H P1=C5 rows=5 (DEFAULT command line)
 *  Command Syntax:
 *  java oop.sticks.SticksGame [P0={H,C[#]}] [P1={H,C[#]}] [HELP] [DEBUG]
 *                     [rows=#][file=<filename>[{.ser,.xml}]] [{SER,XML}]
 *  where {,} indicates a choice, and [] indicates optional.
 *  The P0 & P1 options configure 2 kinds of players: Human & Computer.
 *  The syntax for a Computer Player configuration string (where x = 0 or 1):
 *  Px=C  == Use a Computer Player that makes random moves.
 *  Px=C0 == Ditto: random moves.
 *  Px=C3 == Use a MiniMax Computer Player with search depth = 3.
 *  The "file" option indicates the name of a saved game file.
 *  If provided, then the indicated game should be restored, if possible.
 *  The DEBUG parameter, if present, will enable Minimax DEBUG log messages.
 *  HELP shows the Command Line Syntax.
 *  If SER is present on the command line, then Java's serialization will
 *  be used for saving games (else, a saved game will be an XML file).
 *  ROWS allows setting the number of rows in the board.
 *  All commands may be in upper or lower case.
 *
 *  To save a game, a given player may type "save filename" instead of a move;
 *  This will create a file called either filename.ser or filename.xml.
 */
public class SticksGame implements XMLizable, Serializable
{
  private Layout     layout;
  private Player[]   players;
  private Referee    referee;
  private static boolean USE_XML = true; // default
  private static String  FILE_EXTENSION = ".xml"; // default

  /**
   * Play a game of sticks.
   */
  public static void main( String[] commandLineArgs )
  {
    SticksGame game = null;
    System.out.println( "\n!!!! Welcome to the Sticks Game !!!!" );

    try
    {
      ArgumentParser args = new ArgumentParser( commandLineArgs );
      if( args.hasOption( "h" ) || args.hasOption( "help" ) ||
          args.hasOption( "?" ) || args.hasOption( "-h" ) )
      {
        printCommandLineSyntax();
        return;
      }

      if( args.hasOption( "ser" ) )
      {
        USE_XML = false;
        FILE_EXTENSION = ".ser";
      }

      if( args.hasOption( "file" ) )
      {
        game = restoreGame( (String) args.getOption( "file" ) );
      }
      else
      {
        game = new SticksGame();
        game.init( args );
      }

      if( args.hasOption( "debug" ) )
      {
        Minimax.enableDebugLog( true );
      }

      game.play();
    }
    catch( SaveGameException save )
    {
      // The user has opted to save the game and quit.
      // SaveGameException thrown only by HumanPlayer's makeMove()
      saveGame( game, save.getFileName() );
    }
    catch( Throwable t )
    {
      String args = "";
      for( int i = 0; i < commandLineArgs.length; i++ )
      {
        args += commandLineArgs[ i ];
      }
      System.out.println( "SticksGame ERROR !!!! " );
      System.out.println( "   oop.sticks.SticksGame " + args );
      System.out.println( "   " + StackTrace.toString( t ) );
      printCommandLineSyntax();
    }
    finally
    {
      System.out.println( "!!!! Leaving SticksGame !!!! Goodbye !!!!" );
    }
  }

  /**
   * Create a Player given a configuration string.
   */
  private Player createPlayer( String config )
  throws Exception
  {
    Player player = null;
    char playerType = config.toUpperCase().charAt( 0 );
    switch( playerType )
    {
    case 'C' :
      player = new ComputerPlayer();
      int difficulty = 0;
      if( config.trim().length() > 1 )
      {
        difficulty = Integer.parseInt( config.trim().substring( 1 ) );
      }
      ((ComputerPlayer)player).initStrategy( difficulty, players, layout );
      break;
    case 'H' :
      player = new HumanPlayer();
      player.determineName();
      break;
    default:
      throw new Exception( "Bad player config String " + config );
    }
    return player;
  }

  /**
   * Create the 2 Players given the command line args.
   */
  public void createPlayers( ArgumentParser args )
  throws Exception
  {
    players = new Player[ 2 ];
    String p0config = args.getOption( "p0" );
    if( p0config == null )
    {
      p0config = "H";
    }
    String p1config = args.getOption( "p1" );
    if( p1config == null )
    {
      p1config = "C5"; // default
    }
    players[ 0 ] = createPlayer( p0config );
    players[ 1 ] = createPlayer( p1config );
 }

 /**
  * Initialize a Sticks game given command line args.
  */
  private void init( ArgumentParser args )
  throws Exception
  {
    layout = new Layout();
    referee = new Referee();
    createPlayers( args );
    if( args.hasOption( "rows" ) )
    {
      String rows = args.getOption( "rows" );
      try
      {
        int nr = Integer.valueOf( rows ).intValue();
        layout.setNumRows( nr );
      }
      catch( Throwable t )
      {
        System.out.println( "Sticks WARNING ! Command line option rows=???" );
      }
    }
    referee.init( players, layout );
  }

  public void initFromXML( Element root )
  throws Exception
  {
    layout = new Layout();
    referee = new Referee();

    List playerList = root.getChildren( "player" );
    players = new Player[ 2 ];
    for( int playerNum = 0; playerNum <= 1; playerNum++ )
    {
      Element playerElement = (Element)playerList.get( playerNum );
      Player player = (Player) XMLFactory.makeObject( playerElement );
      players[ playerNum ] = player;
    }

    // The referee is the mediator...
    referee.init( players, layout );

    // Give the CP(s) the extra info they need to seach the layout:
    for( int playerNum = 0; playerNum <= 1; playerNum++ )
    {
      Player player = players[ playerNum ];
      if( player instanceof ComputerPlayer )
      {
        ComputerPlayer cp = (ComputerPlayer) player;
        int depth = cp.getMaxSearchDepth();
        cp.initStrategy( depth, players, layout );
       }
    }

    // Replay the list of moves to set the layout state:
    Move move = null;
    List moveElements = root.getChildren( "move" );
    Iterator it = moveElements.iterator();
    int numMoves = 0;
    while( it.hasNext() )
    {
      Element moveElement = (Element) it.next();
      move = (Move) XMLFactory.makeObject( moveElement );
      layout.processMove( move );
      numMoves++;
    }

    // Determine whos turn is next:
    referee.setNextPlayer( players[ numMoves % 2 ] );
  }

  /**
   * Play a game.
   * Throws SaveGameException if the HumanPlayer decides to save the game.
   */
  private void play() throws SaveGameException
  {
    System.out.println();
    System.out.println( players[ 0 ] + " VS. " );
    System.out.println( players[ 1 ] + " !!!! " );

    referee.conductGame();
    referee.announceWinner();

    System.out.println( "" );
    Console.readLine( "Press << \"enter\" >> to exit: " );
  }

  /**
   * Print out the command ine syntax.
   */
  private static void printCommandLineSyntax()
  {
    System.out.println( "Sticks USAGE :" );
    System.out.println( "java oop.sticks.SticksGame [P0={H,C[#]}] [P1={H,C[#]}] [HELP] [DEBUG] " );
    System.out.println( "                   [rows=#][file=<filename>[{.ser,.xml}]] [{SER,XML}]" );
  }

  private static SticksGame restoreGame( String fileName ) throws Exception
  {
    if( fileName.indexOf( FILE_EXTENSION ) == -1 )
    {
      // Append .xml to the filename if not already there.
      fileName = fileName + FILE_EXTENSION;
    }

    SticksGame game = null;
    if( USE_XML )
    {
      game = (SticksGame) XMLFactory.readFile( fileName );
    }
    else // SER
    {
      FileInputStream file = new FileInputStream( fileName );
      ObjectInputStream input = new ObjectInputStream( file );
      game = (SticksGame) input.readObject(); // de-serialize
      input.close();
    }

    if( game != null )
    {
      System.out.println( "SticksGame Game restored from file " + fileName + " ." );
    }
    return game;
  }

  private static void saveGame( SticksGame game, String fileName )
  {
    try
    {
      if( fileName.indexOf( FILE_EXTENSION ) == -1 )
      {
        // Append .xml to the filename if not already there.
        fileName = fileName + FILE_EXTENSION;
      }
      System.out.println( "Saving Game to file " + fileName + " ..." );

      if( USE_XML )
      {
        XMLFactory.writeFile( fileName, game );
      }
      else // SER
      {
        FileOutputStream file = new FileOutputStream( fileName );
        ObjectOutputStream output = new ObjectOutputStream( file );
        output.writeObject( game );
        output.close();
      }
    }
    catch( Throwable t )
    {
      System.out.println( "SticksGame Warning !!!! Unable to save game " + fileName );
      System.out.println( StackTrace.toString( t ) );
    }
  }

  public Element toXML()
  {
    Element root = new Element( "sticksgame" );
    Attribute classAttr = new Attribute( CLASS_NAME, getClass().getName() );
    root.setAttribute( classAttr );

    root.addContent( players[ 0 ].toXML() );
    root.addContent( players[ 1 ].toXML() );

    Vector moves = layout.getMoves();
    Iterator it = moves.iterator();
    while( it.hasNext() )
    {
      Move move = (Move)it.next();
      root.addContent( move.toXML() );
    }
    return root;
  }
}
