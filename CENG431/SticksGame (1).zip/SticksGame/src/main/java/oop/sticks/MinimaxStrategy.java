// File: <<CLASSPATH>>/oop/sticks/MinimaxStrategy.java
package oop.sticks;

import oop.minimax.*;

/**
 * Wrap the Minimax class.
 */
public class MinimaxStrategy implements Strategy
{
  private int       depth = 0;
  private Layout   layout = null;
  private Player   player = null;
  private Player[] players = null;

  /**
   * Create a MinimaxStrategy with all the parameters that Minimax requires.
   */
  public MinimaxStrategy( Player player, Layout layout,
                          int depth, Player[] players )
  {
    this.player = player;
    this.layout = layout;
    this.depth = depth;
    this.players = players;
  }

  /**
   * Ask Minimax to make a move.
   */
  public Move makeMove()
  {
    Score score = new Score();
    IMove move = Minimax.makeMove( players, layout, depth, player, score );

    System.out.println( "MINIMAX score for next move = " + score );
    if( score.equals( Minimax.SCORE_WIN ) )
    {
      System.out.println( "I've got you now... ha ha ha !!!" );
    }
    if( score.equals( Minimax.SCORE_LOSE ) )
    {
      System.out.println( "Uh oh..." );
    }
    if( score.equals( Minimax.SCORE_TIE ) ) // No tie in Sticks, but...
    {
      System.out.println( "It looks like we're evenly matched..." );
    }
    return (Move) move;
  }
}