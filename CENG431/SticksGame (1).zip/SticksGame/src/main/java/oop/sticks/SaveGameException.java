// File: <<CLASSPATH>>/oops/sticks/SaveGameException.java
package oop.sticks;

public class SaveGameException extends Exception
{
  private String saveFileName;

  protected SaveGameException( String saveString )
  {
    saveFileName = saveString;
  }

  public String getFileName()
  {
    return saveFileName;
  }
}