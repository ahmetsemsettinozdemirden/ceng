package DesignPatternState3;

public class High extends State {

}
