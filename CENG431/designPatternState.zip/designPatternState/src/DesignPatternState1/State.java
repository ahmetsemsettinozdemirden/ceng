package DesignPatternState1;

public interface State {
	
	public void doAction(Context context);
	
}
