package DesignPatternState2;

public interface State {

	public void doAction();

}
