#ifndef CENG112_QUEUE_H
#define CENG112_QUEUE_H

#include <cstdlib>
#include <iostream>

namespace ceng112 {

template <typename T>
class Queue {
public:

    Queue() { m_head = 0; m_size = 0; }
    ~Queue() { clear(); }

    void enqueue(const T& item);
    T dequeue();
    void clear();

    size_t size() const { return m_size; }
    bool is_empty() const { return size() == 0; }

private:
    struct Node {
        T data;
        Node *next;
        Node *prev;
    };

    Node *m_head;
    size_t m_size;
};

template <typename T>
void Queue<T>::enqueue(const T& item)
{


	
    Node *node = new Node;
    node->data = item;

    if (is_empty()) {

        /*
        Old:

        

        New:
                 ---------prev---------|
                 |      ________       |
                 |----| [      ] <-----
        m_head -------> [ item ] 
                 -----> [______] |-----|
                 |                     |
                 |--------next----------
        */

        node->next = node;
        node->prev = node;
        
        m_head = node;

    } else if(size() == 1){

        /*
        Old:
                 ---------prev--------|
                 |      ________      |
                 |----| [      ] <----
        m_head -------> [  x   ] 
                 -----> [______] |----|
                 |                    |
                 |--------next---------

        New:
                 -------------------prev-----------------|
                 |      ________           ________      |
                 |----| [      ] <--prev-- [      ] <-----
        m_head -------> [  x   ]           [ item ]
                 -----> [______] --next--> [______] |----|
                 |                                       |
                 |-----------------next-------------------
        */

        node->next = m_head;
        node->prev = m_head;
        m_head->next = node;
        m_head->prev = node;

        

    } else {

        /*
        Old:
                 ---------------------------prev-------------------------|
                 |      ________                           ________      |
                 |----| [      ] <--prev--       <--prev-- [      ] <-----
        m_head -------> [  x   ]            ...            [  y   ]
                 -----> [______] --next-->       --next--> [______] |----|
                 |                                                       |
                 |--------------------------next--------------------------

        New:
                 ---------------------------prev-------------------------------------------|
                 |      ________                           ________           ________     |
                 |----| [      ] <--prev--       <--prev-- [      ] <--prev-- [      ]<-----
        m_head -------> [  x   ]            ...            [  y   ]           [ item ]
                 -----> [______] --next-->       --next--> [______] --next--> [______]|----|
                 |                                                                         |
                 |--------------------------next--------------------------------------------
        */

        Node *tail = m_head->prev;

        node->next = m_head;
        node->prev = tail;
        tail->next = node;
        m_head->prev = node;
    }
    
    m_size++;

    /*
    // A shorter but less understandable version is (Because else if part is redundant):

    Node *node = new Node;
    node->data = item;

    if (is_empty()) {
        node->next = node;
        node->prev = node;
        m_head = node;
    } else {
        Node *tail = m_head->prev;
        node->next = m_head;
        node->prev = tail;
        tail->next = node;
        m_head->prev = node;
    }

    m_size++;
    */


    /*
    // We may make it even shorter:

    Node *node = new Node;
    node->data = item;

    if (is_empty()) {
        m_head = node;
    } else {
        node->prev = m_head->prev;
        (m_head->prev)->next = node;
    }
    node->next = m_head;
    m_head->prev = node; 

    m_size++;
    */

    
}

template <typename T>
T Queue<T>::dequeue()
{
        
    if(is_empty()) {
        std::cerr << "Can not dequeue fron an empty queue!" << std::endl;
        std::exit(EXIT_FAILURE);

    }

    T item = m_head->data;
    
    if(size() == 1) {
        delete m_head;
        m_head = 0;

    } else {
        Node *tail = m_head->prev;
        Node *new_head = m_head->next;
        delete m_head;
        new_head->prev = tail;
        tail->next = new_head;
        m_head = new_head;
    }

    m_size--;
    return item;
}

template <typename T>
void Queue<T>::clear()
{

    if(is_empty()) return;

    Node *p = m_head->next;
    while(p != m_head) {
        Node *to_delete = p;
        p = p->next;
        delete to_delete;        
    }
    delete m_head;
    m_head = 0;
    m_size = 0;

    /*
    // Easy to understand but inefficient:

    while(!is_empty()) {
        dequeue();
    }
    */

}

}

#endif
