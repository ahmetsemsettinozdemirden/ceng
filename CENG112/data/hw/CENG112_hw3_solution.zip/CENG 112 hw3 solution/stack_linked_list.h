#ifndef CENG112_STACK_H
#define CENG112_STACK_H

#include <cstdlib>
#include <iostream>

namespace ceng112 {

template <typename T>
class Stack {
public:
    Stack(){
        m_head = 0; m_size = 0;
    };
    ~Stack(){
        clear();
    }
    void clear();
    void push(const T& items);
    T pop();
    size_t size() const { return m_size; }
    bool is_empty() const { return m_size == 0; }

private:
    struct Node {
        T data;
        Node *next;
    };

    size_t m_size;
    Node *m_head;
};

template <typename T>
void Stack<T>::push(const T& item)
{
    Node *node = new Node;
    node->data = item;
    node->next = m_head;
    m_head = node;
    m_size++;
}

template <typename T>
T Stack<T>::pop() {
    if (is_empty()) {
        std::cerr << "Can not pop from an empty stack!" << std::endl;
        std::exit(EXIT_FAILURE);
    }

    T item = m_head->data;

    if(size()==1) {
        delete m_head;
        m_head = 0;
    } else {
        Node *to_delete = m_head;
        m_head = m_head->next;
        delete to_delete;                
    }

    m_size--;
    return item;
}

template <typename T>
void Stack<T>::clear() {
	
    Node *p = m_head;
    while(p != 0) {
        Node *to_delete = p;
        p = p->next;
        delete to_delete;        
    }

	m_head = 0;
	m_size = 0;
}

}

#endif
