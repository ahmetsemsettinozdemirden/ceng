// filename: calc.cc                                                                                                                                                                                          
#include <cstdlib>
#include <iostream>
#include <cstring>

using namespace std;

int main(int argc, char* argv[]) {
        if (argc < 2) {
                cerr << "Usage: " << argv[0]
                     << " <+|x> <numbers>" << endl;
                return EXIT_FAILURE;
        }

        if (strcmp(argv[1],"+") == 0) {
                int sum = 0;
                for (int i = 2; i < argc; i++) {
                        sum += atoi(argv[i]);
                }
                cout << sum << endl;

        } else if (strcmp(argv[1],"x") == 0) {
                int mult = 1;
                for (int i = 2; i < argc; i++) {
                        mult *= atoi(argv[i]);
                }
                cout << mult << endl;
        } else {
                cerr << "Invalid operator \"" << argv[1]
                     << "\". The operator should be + or x!" << endl;
                return EXIT_FAILURE;
        }
        return EXIT_SUCCESS;
}
