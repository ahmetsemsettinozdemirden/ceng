// filename: transpose.cc
#include <cstdlib>
#include <iostream>
#include <vector>

using namespace std;

int main(int argc, char* argv[]) {
	int d1 = 0;
	int d2 = 0;
	cin >> d1 >> d2;
	vector<vector <int> > vec(d1,vector <int>(d2));

	for (int i = 0; i < d1; ++i) {
		for (int j = 0; j < d2; ++j) {
			cin >> vec[i][j];			
		}
	}
	cout << "Matrix" <<endl;
	for (int i = 0; i < d1; ++i) {
		for (int j = 0; j < d2; ++j) {
			cout << vec[i][j] << " ";			
		}
		cout << endl;
	}

	vector<vector <int> > transpose(d2,vector <int>(d1));
	for (int i = 0; i < d1; ++i) {
		for (int j = 0; j < d2; ++j) {
			transpose[j][i] = vec[i][j];			
		}
	}
	cout << "Tranpose" <<endl;	
	for (int i = 0; i < d2; ++i) {
		for (int j = 0; j < d1; ++j) {
			cout << transpose[i][j] << " ";			
		}
		cout << endl;
	}


	return EXIT_SUCCESS;
}
