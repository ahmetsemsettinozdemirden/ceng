
#ifndef UTILS_H
#define UTILS_H


double degToRad(double degree);
double metersToKilometers(double meters);
double distanceBetweenCoords(double lat1, double long1, double lat2, double long2);

#endif