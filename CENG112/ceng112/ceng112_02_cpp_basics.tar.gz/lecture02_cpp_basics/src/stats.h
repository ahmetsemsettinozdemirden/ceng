#ifndef STATS_H
#define STATS_H

void min_max_of(int n, float values[],
                float &min_value, float &max_value);
float average_of(int n, float values[]);

#endif
