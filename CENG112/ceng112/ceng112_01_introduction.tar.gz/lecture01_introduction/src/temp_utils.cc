// filename: temp_utils.cc
#include "temp_utils.h"

// Definition of the function fahr_to_celcius
double fahr_to_celcius(double temp)
{
        return (temp - 32.0) * 5.0 / 9.0;
}
